﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MathNet.Numerics.LinearAlgebra;

namespace arithmeticsoperation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var M = Matrix<double>.Build;
            var m1 = M.Random(3, 4);
            labelm1.Text = m1.ToString();
            var m2 = M.Random(3, 4);
            labelm2.Text = m2.ToString();
            var add = m1.Add(m2);
            labeladd.Text = add.ToString();
            var sub = m1.Subtract(m2);
            labelsub.Text = sub.ToString();
            m2 = m2.Transpose();
            labelm2t.Text = m2.ToString();
            var mul = m1.Multiply(m2);
            labelmul.Text = mul.ToString();
            var div = m1.Divide(2);
            labeldiv.Text = div.ToString();
        }
    }
}
