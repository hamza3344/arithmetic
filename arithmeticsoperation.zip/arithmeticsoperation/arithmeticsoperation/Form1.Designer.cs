﻿
namespace arithmeticsoperation
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.labelm1 = new System.Windows.Forms.Label();
            this.labelm2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelm2t = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labeladd = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelsub = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelmul = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labeldiv = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(52, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "m1";
            // 
            // labelm1
            // 
            this.labelm1.AutoSize = true;
            this.labelm1.Location = new System.Drawing.Point(31, 51);
            this.labelm1.Name = "labelm1";
            this.labelm1.Size = new System.Drawing.Size(38, 15);
            this.labelm1.TabIndex = 1;
            this.labelm1.Text = "label2";
            // 
            // labelm2
            // 
            this.labelm2.AutoSize = true;
            this.labelm2.Location = new System.Drawing.Point(320, 51);
            this.labelm2.Name = "labelm2";
            this.labelm2.Size = new System.Drawing.Size(38, 15);
            this.labelm2.TabIndex = 3;
            this.labelm2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(341, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "m2";
            // 
            // labelm2t
            // 
            this.labelm2t.AutoSize = true;
            this.labelm2t.Location = new System.Drawing.Point(571, 51);
            this.labelm2t.Name = "labelm2t";
            this.labelm2t.Size = new System.Drawing.Size(38, 15);
            this.labelm2t.TabIndex = 5;
            this.labelm2t.Text = "label2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(592, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 21);
            this.label4.TabIndex = 4;
            this.label4.Text = "m2 of transpose";
            // 
            // labeladd
            // 
            this.labeladd.AutoSize = true;
            this.labeladd.Location = new System.Drawing.Point(31, 254);
            this.labeladd.Name = "labeladd";
            this.labeladd.Size = new System.Drawing.Size(38, 15);
            this.labeladd.TabIndex = 7;
            this.labeladd.Text = "label2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(52, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 21);
            this.label5.TabIndex = 6;
            this.label5.Text = "Addition";
            // 
            // labelsub
            // 
            this.labelsub.AutoSize = true;
            this.labelsub.Location = new System.Drawing.Point(488, 254);
            this.labelsub.Name = "labelsub";
            this.labelsub.Size = new System.Drawing.Size(38, 15);
            this.labelsub.TabIndex = 9;
            this.labelsub.Text = "label2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(509, 221);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 21);
            this.label6.TabIndex = 8;
            this.label6.Text = "Subtraction";
            // 
            // labelmul
            // 
            this.labelmul.AutoSize = true;
            this.labelmul.Location = new System.Drawing.Point(31, 445);
            this.labelmul.Name = "labelmul";
            this.labelmul.Size = new System.Drawing.Size(38, 15);
            this.labelmul.TabIndex = 11;
            this.labelmul.Text = "label2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(52, 412);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 21);
            this.label7.TabIndex = 10;
            this.label7.Text = "Multiplication";
            // 
            // labeldiv
            // 
            this.labeldiv.AutoSize = true;
            this.labeldiv.Location = new System.Drawing.Point(488, 445);
            this.labeldiv.Name = "labeldiv";
            this.labeldiv.Size = new System.Drawing.Size(38, 15);
            this.labeldiv.TabIndex = 13;
            this.labeldiv.Text = "label2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(509, 412);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 21);
            this.label8.TabIndex = 12;
            this.label8.Text = "Divide by 2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 620);
            this.Controls.Add(this.labeldiv);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.labelmul);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelsub);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.labeladd);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelm2t);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelm2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelm1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelm1;
        private System.Windows.Forms.Label labelm2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelm2t;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labeladd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelsub;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelmul;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labeldiv;
        private System.Windows.Forms.Label label8;
    }
}

